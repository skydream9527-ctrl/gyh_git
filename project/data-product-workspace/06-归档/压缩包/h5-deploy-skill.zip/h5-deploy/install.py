#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path

SKILL_NAME = "h5-deploy"
SKILL_DIR = Path(__file__).resolve().parent.parent
CENTRAL_INSTALL_ROOT = Path.home() / ".agents" / "skills"
DEFAULT_CONFIG = Path.home() / ".config" / "h5-deploy" / "config.toml"

DEPLOY_HOSTNAME = os.environ.get("DEPLOY_HOSTNAME", "http://ai.ice.miui.srv")
DEPLOY_URL = os.environ.get("DEPLOY_URL", "http://ai.ice.miui.srv/api/deploy")

CLIENT_TARGETS = [
    ("claude", Path.home() / ".claude" / "skills"),
    ("codex", Path.home() / ".codex" / "skills"),
    ("opencode-config", Path.home() / ".config" / "opencode" / "skills"),
    ("opencode-home", Path.home() / ".opencode" / "skills"),
    ("trae", Path.home() / ".trae" / "skills"),
    ("trae-cn", Path.home() / ".trae-cn" / "skills"),
]


def install(overwrite: bool) -> int:
    central = CENTRAL_INSTALL_ROOT / SKILL_NAME
    if central.exists() or central.is_symlink():
        if not overwrite:
            print(f"  kept: {central} (use --overwrite to replace)")
        else:
            if central.is_symlink() or central.is_file():
                central.unlink()
            else:
                shutil.rmtree(central)
            central.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(SKILL_DIR, central)
            print(f"  installed: {central}")
    else:
        central.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(SKILL_DIR, central)
        print(f"  installed: {central}")

    linked = []
    for name, parent in CLIENT_TARGETS:
        link = parent / SKILL_NAME
        parent.mkdir(parents=True, exist_ok=True)
        if link.is_symlink():
            if link.resolve() == central.resolve():
                linked.append((name, "already linked"))
                continue
            if not overwrite:
                linked.append((name, "skipped"))
                continue
            link.unlink()
        elif link.exists():
            if not overwrite:
                linked.append((name, "skipped"))
                continue
            if link.is_dir():
                shutil.rmtree(link)
            else:
                link.unlink()
        link.symlink_to(central, target_is_directory=True)
        linked.append((name, "linked"))

    for name, state in linked:
        print(f"  🔗 {name:20s} {state}")

    config_path = DEFAULT_CONFIG
    if not config_path.exists() or overwrite:
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text(
            f'[deploy]\n'
            f'default_branch = "main"\n'
            f'default_version = "draft"\n'
            f'public_hostname = "{DEPLOY_HOSTNAME}"\n'
            f'deploy_url = "{DEPLOY_URL}"\n',
            encoding="utf-8",
        )
        print(f"  📄 config: {config_path} (created)")
    else:
        print(f"  📄 config: {config_path} (kept)")

    print()
    print("✨ Ready to deploy. Say to your AI: \"部署这个 H5：<path>\"")
    return 0


def uninstall(purge: bool) -> int:
    central = CENTRAL_INSTALL_ROOT / SKILL_NAME
    for name, parent in CLIENT_TARGETS:
        link = parent / SKILL_NAME
        if link.is_symlink():
            link.unlink()
            print(f"  unlinked: {link}")
    if purge:
        if central.exists():
            shutil.rmtree(central)
            print(f"  removed: {central}")
        if DEFAULT_CONFIG.exists():
            DEFAULT_CONFIG.unlink()
            print(f"  removed: {DEFAULT_CONFIG}")
    else:
        print(f"  entity kept: {central} (use --purge to remove)")
    return 0


def doctor() -> int:
    central = CENTRAL_INSTALL_ROOT / SKILL_NAME
    print(f"  📦 entity: {central} ({'present' if central.exists() else 'MISSING'})")
    for name, parent in CLIENT_TARGETS:
        link = parent / SKILL_NAME
        if link.is_symlink():
            try:
                ok = link.resolve() == central.resolve()
                print(f"  🔗 {name:20s} linked {'✅' if ok else '⚠️ different'}")
            except OSError:
                print(f"  🔗 {name:20s} DANGLING")
        else:
            print(f"  🔗 {name:20s} absent")
    if DEFAULT_CONFIG.exists():
        body = DEFAULT_CONFIG.read_text(encoding="utf-8")
        if DEPLOY_SECRET in body:
            print(f"  🚀 deploy api: configured")
        else:
            print(f"  🚀 deploy api: ⚠️ secret mismatch")
    else:
        print(f"  🚀 deploy api: ❌ no config")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Install h5-deploy skill")
    sub = parser.add_subparsers(dest="action")

    install_p = sub.add_parser("install")
    install_p.add_argument("--overwrite", action="store_true")
    install_p.add_argument("--all", action="store_true")

    uninstall_p = sub.add_parser("uninstall")
    uninstall_p.add_argument("--purge", action="store_true")

    sub.add_parser("doctor")

    args = parser.parse_args()
    if args.action == "uninstall":
        return uninstall(args.purge)
    if args.action == "doctor":
        return doctor()
    return install(args.overwrite)


if __name__ == "__main__":
    raise SystemExit(main())

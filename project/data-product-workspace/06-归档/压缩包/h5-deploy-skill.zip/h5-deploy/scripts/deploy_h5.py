#!/usr/bin/env python3
from __future__ import annotations

import base64
import json
import os
import socket
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:
    try:
        import tomli as tomllib
    except ModuleNotFoundError:
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "--quiet", "tomli"],
                check=True,
            )
            import tomli as tomllib
        except Exception:
            raise RuntimeError("Python 3.11+ required, or run: pip install tomli") from None

DEFAULT_CONFIG = Path.home() / ".config" / "h5-deploy" / "config.toml"

CATEGORY_ALIASES = {
    "产品": "product", "设计": "design", "研发": "dev", "测试": "test",
}
BUSINESS_ALIASES = {
    "浏览器": "browser", "内容中心": "content", "桌面信息流": "feed",
    "视频": "video", "搜索": "search", "广告": "ads",
    "应用商店": "appstore", "天气": "weather", "日历": "calendar",
    "便签": "notes", "音乐": "music",
}


def read_config(path: Path) -> dict:
    if not path.exists():
        return {}
    with path.open("rb") as handle:
        return tomllib.load(handle)


def cfg(raw: dict, section: str, key: str, default: str = "") -> str:
    sec = raw.get(section, {})
    if not isinstance(sec, dict):
        return default
    return str(sec.get(key, default)).strip()


def slug(raw: str) -> str:
    import re, unicodedata
    cleaned = (raw or "").strip()
    if not cleaned:
        return "item"
    decomposed = unicodedata.normalize("NFKD", cleaned)
    ascii_only = decomposed.encode("ascii", "ignore").decode("ascii").lower()
    slug = re.sub(r"[^a-z0-9]+", "-", ascii_only)
    slug = re.sub(r"-+", "-", slug).strip("-")
    return slug if len(slug) >= 2 else f"item-{hash(cleaned) % 10**8:08d}"


def normalize_category(raw: str) -> str:
    return CATEGORY_ALIASES.get((raw or "").strip(), raw or "").lower()


def normalize_business(raw: str) -> str:
    cleaned = (raw or "").strip()
    if cleaned in BUSINESS_ALIASES:
        return BUSINESS_ALIASES[cleaned]
    return slug(cleaned)


def operator_info() -> dict:
    email = ""
    name = ""
    try:
        email = subprocess.run(
            ["git", "config", "--get", "user.email"],
            capture_output=True, text=True, timeout=2, check=False,
        ).stdout.strip()
    except Exception:
        pass
    try:
        name = subprocess.run(
            ["git", "config", "--get", "user.name"],
            capture_output=True, text=True, timeout=2, check=False,
        ).stdout.strip()
    except Exception:
        pass
    import getpass
    try:
        user = getpass.getuser()
    except Exception:
        user = os.environ.get("USER") or os.environ.get("USERNAME") or "unknown"
    try:
        host = socket.gethostname()
    except Exception:
        host = "unknown"
    return {"email": email, "name": name, "user": user, "host": host}


def main(argv: list[str] | None = None) -> int:
    argv = list(argv or sys.argv[1:])
    config_path = Path.home() / ".config" / "h5-deploy" / "config.toml"
    source: Path | None = None
    category = ""
    business = ""
    version = ""
    title = ""
    as_json = False

    it = iter(argv)
    for arg in it:
        if arg == "--config":
            config_path = Path(next(it)).expanduser()
        elif arg == "--source":
            source = Path(next(it)).expanduser()
        elif arg == "--category":
            category = next(it)
        elif arg == "--business":
            business = next(it)
        elif arg == "--version":
            version = next(it)
        elif arg == "--title":
            title = next(it)
        elif arg == "--json":
            as_json = True
        elif arg in ("--help", "-h"):
            print("Usage: deploy_h5.py deploy --source FILE --category CAT --business BIZ --version VER --title TITLE [--json]")
            return 0

    raw = read_config(config_path)
    deploy_url = cfg(raw, "deploy", "deploy_url") or os.environ.get("DEPLOY_URL", "http://ai.ice.miui.srv/api/deploy")
    deploy_secret = cfg(raw, "deploy", "deploy_secret") or os.environ.get("DEPLOY_SECRET", "")
    public_hostname = cfg(raw, "deploy", "public_hostname") or os.environ.get("DEPLOY_HOSTNAME", "http://ai.ice.miui.srv")

    if not deploy_url:
        print(f"ERROR: deploy_url must be set in {config_path} or DEPLOY_URL env var", file=sys.stderr)
        return 2

    if not source or not source.is_file():
        print(f"ERROR: --source must be a valid file", file=sys.stderr)
        return 2
    if not category:
        print("ERROR: --category required (product/design/dev/test or Chinese)", file=sys.stderr)
        return 2
    if not business:
        print("ERROR: --business required", file=sys.stderr)
        return 2

    category_slug = normalize_category(category)
    business_slug = normalize_business(business)
    version_slug = slug(version) if version else "draft"
    title_label = title or source.stem
    title_slug = slug(title_label)

    op = operator_info()
    content = source.read_bytes()

    payload = {
        "category": category_slug,
        "business": business_slug,
        "business_label": business,
        "version": version_slug,
        "title": title_slug,
        "title_label": title_label,
        "kind": "file",
        "content_base64": base64.b64encode(content).decode("ascii"),
        "source_name": source.name,
        "operator_email": op["email"],
        "operator_name": op["name"],
        "operator_user": op["user"],
        "operator_host": op["host"],
    }
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")

    request = urllib.request.Request(
        deploy_url,
        data=body,
        method="POST",
        headers={
            "X-Deploy-Secret": deploy_secret,
            "Content-Type": "application/json",
            "User-Agent": "h5-deploy-skill/2",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            result = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        err = exc.read().decode("utf-8", errors="replace")
        if as_json:
            print(json.dumps({"ok": False, "status": exc.code, "error": err[:500]}, ensure_ascii=False))
        else:
            print(f"❌ 部署失败 (HTTP {exc.code}): {err[:200]}", file=sys.stderr)
        return 1
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        if as_json:
            print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        else:
            print(f"❌ 网络错误: {exc}", file=sys.stderr)
        return 1

    relative_path = f"{category_slug}/{business_slug}/{version_slug}/{title_slug}.html"
    # 默认走 SPA 外壳（带左侧目录）：/#/path.html
    # 想直接看独立页可手动去掉 URL 里的 #
    public_url = (public_hostname.rstrip("/") + f"/#/{relative_path}") if public_hostname else f"/#/{relative_path}"

    if as_json:
        print(json.dumps({
            "ok": True,
            "relative_path": relative_path,
            "url_path": f"/{relative_path}",
            "public_url": public_url,
            "trigger": result,
        }, ensure_ascii=False, indent=2))
    else:
        print(f"✅ 已部署：public/{relative_path}")
        print(f"🚀 已 push 到 GitLab（commit: {result.get('commit', '')[:8]}）")
        print(f"🌐 立刻访问：{public_url}")
        try:
            subprocess.run(["open", public_url], check=False)
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

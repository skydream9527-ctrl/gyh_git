# Skill: h5-deploy

把任意 H5 文件/文件夹/源码归档到 `ai-native-h5-deploy` GitLab 仓库 → push → CI 自动部署。

## 安装

从仓库根目录运行：

```bash
python3 scripts/install_skill.py            # 自动检测本机已装的 AI 客户端
python3 scripts/install_skill.py install --all  # 强制装进所有支持的客户端
```

支持的 AI 客户端（实体在 `~/.agents/skills/h5-deploy/`，各客户端通过 symlink 共享）：

- Claude Code → `~/.claude/skills/h5-deploy`
- Codex → `~/.codex/skills/h5-deploy`
- OpenCode → `~/.config/opencode/skills/h5-deploy` 和 `~/.opencode/skills/h5-deploy`
- Trae / Trae CN → `~/.trae/skills/h5-deploy` 和 `~/.trae-cn/skills/h5-deploy`

它会同时在 `~/.config/h5-deploy/config.toml` 写入预置共享 token（占位版本会写占位）。

体检与卸载：

```bash
python3 scripts/install_skill.py doctor
python3 scripts/install_skill.py uninstall          # 只拆 symlink
python3 scripts/install_skill.py uninstall --purge  # 连实体和 config 一起删
```

## 凭证

**默认情况下不需要配账号**——`install_skill.py` 在安装时会内置一个共享的 GitLab Project Access Token 写到 `~/.config/h5-deploy/config.toml`，开箱即用。

如果你看到 `~/.config/h5-deploy/config.toml` 里 token 还是 `__GITLAB_TOKEN__` 占位，说明你拿到的是没有内置 token 的版本。两种解决方式：

1. **拿到内置 token 版本的安装包**重装：`python3 scripts/install_skill.py --overwrite --force-config`
2. **手动填**：编辑 `~/.config/h5-deploy/config.toml`，在 `[gitlab]` 下填 `token = "glpat-xxxxxxxx"`（自己的 PAT 也行）

## 真实操作人记录

虽然 token 是共享的（commit author 显示为机器人），但每次 commit 的 body 里会自动嵌入：

```
Operator: zhangsan@xiaomi.com (zhangsan@zhangsan-mbp)
Operator-Email: zhangsan@xiaomi.com
Operator-Name:  张三
Operator-User:  zhangsan
Operator-Host:  zhangsan-mbp
```

数据来自你本机的 `git config user.email`、`whoami`、`hostname`。可追溯。

## 使用

在 Claude / Codex 里说：

> 部署这个 H5：~/Downloads/搜索PRD.html，归档到 产品/浏览器/v10.1/搜索需求PRD

或粘贴一段 HTML 源码，AI 会自动写到临时文件再 deploy。

## 直接调命令行

```bash
python3 ~/.cache/ai-native-h5-deploy/repo/scripts/deploy_h5.py deploy \
  --source ~/Downloads/搜索PRD.html \
  --category 产品 --business 浏览器 --version v10.1 \
  --title 搜索需求PRD \
  --commit --push --json
```

---
name: h5-deploy
version: 0.2.0
description: "Deploy and archive H5/HTML pages (PRDs, design mocks, research docs, test reports) into the shared GitLab repo. Use whenever the user says 部署这个 h5, 部署这个 H5, 部署这个 PRD, 发布这个 H5, 把这个 H5 部署一下, 归档并部署 H5, deploy this h5, deploy this prd, deploy this html, publish this h5. CRITICAL: must explicitly ask the user for category (product/design/dev/test), business (业务线), version (版本号), and title before invoking — NEVER infer these from filenames, file types, or context. The skill archives the file/folder under public/{product|design|dev|test}/{business}/{version}/, commits and pushes to GitLab, then triggers the deploy API which fetches the latest code and serves the H5 via FastAPI."
triggers:
  - "部署这个 h5"
  - "部署这个 H5"
  - "部署这个 PRD"
  - "部署这个 prd"
  - "发布这个 H5"
  - "发布这个 h5"
  - "把这个 H5 部署一下"
  - "把这个 h5 部署一下"
  - "归档并部署 H5"
  - "归档并部署 h5"
  - "deploy this h5"
  - "deploy this prd"
  - "deploy this html"
  - "publish this h5"
metadata:
  requires:
    bins: ["git", "python3"]
    python: ">=3.9"
  cliHelp: "python3 ~/.cache/ai-native-h5-deploy/repo/scripts/deploy_h5.py deploy --help"
---

# h5-deploy

把一份 H5（HTML 文件、含 js/css 的文件夹、或粘贴的 HTML 源码）归档到 `ai-native-h5-deploy` GitLab 仓库，commit + push 触发 Pipeline 自动部署。

## 触发词

- "部署这个 H5" / "部署这个 PRD" / "发布这个 H5"
- "把这个 H5 部署一下" / "归档并部署 H5"
- "deploy this h5" / "deploy this prd"

## 必填字段（缺一个就追问，**禁止脑补**）

| 字段 | 含义 | 例子 |
|---|---|---|
| `category` | 一级职能目录，**只能是 4 选 1** | `product` / `design` / `dev` / `test`（中文 `产品/设计/研发/测试` 自动映射） |
| `business` | 产品线（ASCII 优先） | `browser` / `content` / `video`（中文 `浏览器/内容中心/视频` 自动映射） |
| `version` | 版本号 | `v10.1` / `v11.0` / `draft` |
| `title` | 需求/文档标题（中英都行） | `搜索需求PRD` / `首页设计稿` |
| `source` | H5 来源（三选一） | 本地路径 / 粘贴源码 / `--html-file` |

### ⛔️ 强制规则（CRITICAL — DO NOT VIOLATE）

**只要用户消息里没有显式给出 `category` / `business` / `version`，就必须停下来追问，禁止任何形式的"自动判断 / 智能推断 / 默认值"**。

具体禁令：

- ❌ 看到 PRD 文件 → 自动判 `product`。**禁止**。PRD 也可能是 `dev`（技术 PRD）/ `design`（设计稿评审）。
- ❌ 看到代码文件 → 自动判 `dev`。**禁止**。
- ❌ 看到 figma / 设计稿截图 → 自动判 `design`。**禁止**。
- ❌ 从文件名包含 `browser` 推断 `business=browser`。**禁止**。
- ❌ 用 `draft` 作为 version 默认值。**禁止**。version 必须用户明确给出。

**唯一允许跳过追问的情况**：用户在**同一条**消息里把全部 4 个字段都明确写出来了（如"部署到 产品 浏览器 v10.1，标题叫搜索需求PRD"）。只要有 1 个字段没明说，就必须追问。

### 追问模板

```
准备部署 H5，请明确以下 4 项（缺一不可）：

1. **职能** category（必选 1 个）：
   - product（产品）
   - design（设计）
   - dev（研发）
   - test（测试）

2. **业务** business（已知业务：浏览器 / 全搜 / 内容中心 / 小米推送 / 桌面信息流 / 视频 / 广告 / 应用商店 / 天气 / 日历 / 便签 / 音乐，可填新业务）：

3. **版本号** version（如 v10.1 / v0.2 / draft）：

4. **标题** title（中英都行）：
```

只有用户回复了这 4 项后才能执行 deploy 命令。

### source 字段处理

`source` 优先级：用户给本地路径 → 用 `--source`；用户粘贴 HTML 源码 → 写到临时文件用 `--html-file`；不要让用户走 stdin（在 AI 对话场景里 stdin 不可达）。

### 路径命名（重要）

- **URL 路径全部 ASCII**：脚本会自动把 `category` / `business` / `title` 转成英文 slug（中文 → 别名表 → 否则取 ASCII 字符 → 否则哈希）。
- **Chinese 标题/产品线在 manifest.json 里完整保留**，index 页面显示中文，URL 用 ASCII。
- AI 调用时**直接传中文也行**，传英文 slug 也行；脚本会做归一化。
- 例子：`category=产品 business=浏览器 title=搜索需求PRD` → URL `/product/browser/v10.1/prd.html`（页面内 title 还是 "搜索需求PRD"）。

## 凭证模型

**零配置**。用户不需要 GitLab token、SSH key、deploy_secret。

- 内网部署（`.srv` 域名），靠网络隔离做安全边界
- 部署由服务器代为 push，使用服务器内置的 GitLab token
- **真实操作人**通过 commit message body 里的 `Operator-Email` / `Operator-Host` 字段记录，从用户本机的 `git config user.email` 自动解析
- commit author 是服务器机器人账号，可追溯性靠 commit body

## 工作流

1. 读 `~/.config/h5-deploy/config.toml`，校验 `deploy_url` 存在（其他字段可选）。
2. **检查 `category` / `business` / `version` / `title` 4 个字段是否都在用户消息里显式出现**：
   - 4 个全有 → 进入第 3 步
   - 缺任何 1 个 → 用上文「追问模板」反问，**停止执行**，等用户回复后再继续
   - 不要从文件名、文件类型、文件内容、上下文猜测任何字段
3. 调底层命令：

```bash
python3 ~/.agents/skills/h5-deploy/scripts/deploy_h5.py deploy \
  --source "<本地路径>" \
  --category "<product|design|dev|test>" \
  --business "<产品线，e.g. browser/content；中文也行>" \
  --version "<版本>" \
  --title "<标题，中英都可>" \
  --json
```

4. 解析返回 JSON：
   - `public_url` 是完整可访问 URL
   - `trigger.ok=true` 表示服务器已接收文件 + git push 完成，**用户可以立刻打开链接**
   - `trigger.ok=false` 表示部署失败，检查 `trigger.detail`
5. **自动打开浏览器**：部署成功后，立刻用 Bash 执行 `open <public_url>`（macOS）或 `xdg-open <public_url>`（Linux）在浏览器打开链接。这是默认行为，不需要问用户。

## 配置文件

`~/.config/h5-deploy/config.toml`（安装时自动生成）：

```toml
[deploy]
default_branch = "main"
default_version = "draft"
public_hostname = "http://ai.ice.miui.srv"
deploy_url = "http://ai.ice.miui.srv/api/deploy"
```

## 报告输出格式

部署成功（默认场景）：

```
✅ 已部署：public/{category}/{business}/{version}/{title}.html
🚀 已 push 到 GitLab
🌐 立刻访问：<public_url>
```

部署失败：

```
❌ 部署失败：<trigger.detail>
```
